/*
Se desea un programa que pida por pantalla un tamaño de matriz (cuadrada) y rellene valores del 0 al 9 aleatorios. Además se deben solicitar unas coordenadas X e Y para localizar en dicho punto un pico, un valle o una meseta:
Pico: la coordenada es el valor más alto de los que lo rodean
Valle: la coordenada es el valor más bajo de los que lo rodean
Meseta: la coordenada es el valor medio redondeado o al menos hay 3 números adyacentes iguales al dado.
 */
import java.util.Random;
import java.util.Scanner;

public class PruebaEscalada {
    public static void main(String[] args) {
        System.out.println("Dame tamaño matriz cuadrada");
        Scanner sc = new Scanner(System.in);
        int indice = sc.nextInt();

        sc.nextLine();
        int aMatriz[][] = new int[indice][indice];
        Random rdm = new Random();

        for (int i = 0; i < indice; i++) {
            for (int j = 0; j < indice; j++) {
                aMatriz[i][j] = rdm.nextInt(10);
            }
        }
        for (int i = 0; i < indice; i++) {
            for (int j = 0; j < indice; j++) {
                System.out.print(aMatriz[i][j] + " ");
            }
            System.out.println();
        }
        System.out.println("Dame una posicion de la matriz");
        int iX = sc.nextInt();
        int iY = sc.nextInt();
        int iValorPosicion = aMatriz[iX][iY];                //valor posicion a comparar

        System.out.println("El valor de la posicion es " + iValorPosicion);

        boolean esPico = false;
        boolean esValle = false;
        boolean esMeseta = false;
        double sumaTotal = 0;
        double cont = 0;
        for (int i = (iX-1); i < (iX+1); i++) {                      //caso centrico
            for (int j = (iY - 1); j < (iY + 1); j++) {


                    if (aMatriz[i][j] != aMatriz[iX][iY]) {

                    if (aMatriz[i][j] < aMatriz[iX][iY]) {
                        esPico = true;
                    }
                    if (aMatriz[i][j] > aMatriz[iX][iY]) {
                        esValle = true;

                    }
                }


            }
        }
        if (esPico == true){
            System.out.println("es pico");
        }
        if (esValle == true){
            System.out.println("es valle");
        }
        if (esMeseta == true){
            System.out.println("es meseta");
        }

    }
}






